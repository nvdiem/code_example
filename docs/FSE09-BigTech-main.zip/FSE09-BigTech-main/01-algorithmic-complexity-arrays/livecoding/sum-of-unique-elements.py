class Solution(object):
    # TC: O(N) voi N la so phan tu cua nums
    # SC: O(1)
    def sumOfUnique(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        # frequency[i] là số lần xuất hiện của i trong nums
        # frequency[1] = 1, frequency[2] = 2, frequency[3] = 1 (Example 1)
        frequency = [0] * 101 
        for num in nums:
            frequency[num] += 1
        
        ans = 0
        for num in nums:
            if frequency[num] == 1:
                ans += num
        return ans 

