class Solution:
    def merge(self, nums1: List[int], m: int, nums2: List[int], n: int) -> None:
        """
        Do not return anything, modify nums1 in-place instead.
        """
        
        # Cách 1: Tạo một mảng mới nums3 = nums1 + nums2. Sort nums3 rồi trả về.
        # Độ phức tạp: O((M + N)log(M + N))

        # Cách 2: Dùng 2 con trỏ
        # Ý tưởng: Con trỏ left bắt đầu từ cuối mảng 1
        # Con trỏ right bắt đầu từ cuối mảng 2.
        # So sánh nums1[left] và nums2[right], nếu nums1[left] > nums2[right] thì lấy nums1[left], đẩy left sang trái. Nếu 
nums1[left] <= nums2[right] thì lấy nums2[right], đẩy right sang trái. Đến khi nào một trong 2 con trỏ đi hết (< 0), thì dừng lại.

        # [1, 2, 3/l, 0, 0, 0/i] [2, 5, 6/r], l = 2, r = 2, i = 5
        # [1, 2, 3/l, 0, 0/i, 6] [2, 5/r, 6], l = 2, r = 1, i = 4
        # [1, 2, 3/l, 0/i, 5, 6], [2/r, 5, 6], l = 2, r = 0, i = 3
        # [1, 2/l, 3/i, 3, 5, 6], [2/r, 5, 6], l = 1, r = 0, i = 2
        # [1, 2/l/i, 2, 3, 5, 6], r[2, 5, 6], l = 1, r = -1, i = 1

        # TC: O(M + N)
        # SC: O(1)

        left, right = m - 1, n - 1
        index = m + n - 1

        while left >= 0 and right >= 0:
            if nums1[left] > nums2[right]:
                nums1[index] = nums1[left]
                left -= 1
                index -= 1
            else:
                nums1[index] = nums2[right]
                right -= 1
                index -= 1
        
        while right >= 0:
            nums1[index] = nums2[right]
            right -= 1
            index -= 1
        

        


