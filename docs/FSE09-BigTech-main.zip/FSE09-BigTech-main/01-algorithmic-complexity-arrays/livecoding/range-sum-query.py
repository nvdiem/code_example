class NumArray(object):

    #Cách "trâu": với mỗi query sumRange(left, right), cộng tất cả các số với index từ left đến right lại rồi trả về. --> độ phức 
tạp: O(right - left) cho mỗi query, O(N) cho init (vì mình cần copy nums vào self.nums)

    # Cách tối ưu: sử dụng prefix sum
    # Prefix sum là một mảng ps sao cho ps[i] = tổng của i - 1 số đầu tiên
    # Ví dụ: arr = [-2, 0, 3, -5, 2, -1]
    # ps = [0, -2, -2, 1, -4, -2, -3]
    # sumRange(left, right) = ps[right + 1] - ps[left]

    # ps[0] = 0
    # ps[i] = nums[i - 1] + ps[i - 1]

    # TC: O(N) cho init, O(1) cho sumRange
    # SC: O(N) 

    # Ngoài prefix sum, có thể ứng dụng kĩ thuật tương tự để tính prefix max, prefix min, prefix product

    def __init__(self, nums):
        """
        :type nums: List[int]
        """
        self.ps = [0]
        for num in nums:
            self.ps.append(self.ps[-1] + num)
        

    def sumRange(self, left, right):
        """
        :type left: int
        :type right: int
        :rtype: int
        """
        return self.ps[right + 1] - self.ps[left]
        


# Your NumArray object will be instantiated and called as such:
# obj = NumArray(nums)
# param_1 = obj.sumRange(left,right)
