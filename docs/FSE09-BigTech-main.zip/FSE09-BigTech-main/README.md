# Chào mừng đến với khoá học của FSE09-BigTech

## Giới thiệu chung
1. Đây là nơi mọi người có thể nộp bài tập và thảo luận về code.
2. Sau mỗi buổi học các bạn sẽ có bài tập về nhà để luyện tập

## Hướng dẫn nộp bài - Có 2 cách
**LƯU Ý: Các bạn không merge branch của mình vào `main` branch và không push code trực tiếp lên `main` branch.**

### Cách 1: Dùng Github Desktop
- Bước 1: Tải Github Desktop tại đây: https://desktop.github.com/
- Bước 2: Clone repository `https://github.com/FSEOrg/FSE09-BigTech.git` về máy của bạn
  
  Sau mỗi buổi học, các bạn sẽ thấy thư mục mới cho bài tập ở master branch tương ứng với số bài học. Ví dụ: sau bài học số 3, ở master branch sẽ có folder hw03. Trong mỗi folder sẽ có 2 subfolders
    - ```livecoding```: chứa các đoạn code demo trong buổi học
    - ```homework```: chứa các bài tập về nhà cho buổi học
- Bước 3: Tạo branch mới, đặt tên theo cú pháp `hw[số bài học]-[tencuaban]`, ví dụ `hw02-maithanhhiep`
- Bước 4: Chọn những file cần commit và nhấn nút `Commit` (màu xanh dương)
- Bước 5: Push code đã commit lên remote
- Bước 6: Mở trang web https://github.com/FSEOrg/FSE09-BigTech , bạn sẽ thấy có nút để tạo Pull Request, hãy tạo Pull Request để các giảng viên review nhé.

### Cách 2: Dùng Git Command
 1. Các bạn có thể tham khảo thêm về cách dùng Git/Github ở đây:  [https://product.hubspot.com/blog/git-and-github-tutorial-for-beginners](https://product.hubspot.com/blog/git-and-github-tutorial-for-beginners)

 2. Nếu đây là lần đầu bạn đến với repo này thì bạn cần clone project này trước
    ```
    git clone https://github.com/FSEOrg/FSE09-BigTech.git
    cd FSE09-BigTech
    ``` 
 3. Sau mỗi buổi học, các bạn sẽ thấy thư mục mới cho bài tập ở master branch tương ứng với số bài học. Ví dụ: sau bài học số 3, ở master branch sẽ có folder hw03. Trong mỗi folder sẽ có 2 subfolders
    - ```livecoding```: chứa các đoạn code demo trong buổi học
    - ```homework```: chứa các bài tập về nhà cho buổi học
 4. Các bạn hãy pull code mới nhất từ master branch về máy (bạn hãy chắc chắn mình đang ở ```main``` branch trước khi tiếp tục, có thể kiểm tra branch hiện tại bằng lệnh ```git branch```)
    ```
    cd FSE09-BigTech
    git checkout main
    git status  -> hãy kiểm tra bạn đang ở main branch
    git pull origin main
    ```
 5. Tại máy của bạn, tạo branch mới với tên thuộc format sau: hw[số bài học]-[tencuaban]. Tên branch của bạn cần có format này để review. Ví dụ: ```hw02-maithanhhiep``` nếu như bạn đang làm bài tập cho buổi số 2 và tên của bạn là *maithanhhiep* 
	 ```
	 git checkout -b hw02-maithanhhiep
	 ```
 6. Bạn hãy viết lời giải vào file tương ứng với mỗi bài tập trong slide buổi học và commit tất cả lới giải và push lên remote branch của bạn. Bạn có thể tạo nhiều commit, miễn là bạn push tất cả code của bạn lên repo trước deadline để được review code.
    
    Để xem lại những file đã thay đổi bạn gõ `git status`
    - Những file màu đỏ: Là những file đã thay đổi nhưng chưa được add vào git để chuẩn bị commit
    - Những file màu xanh: Là những file đã thay đổi và đã được add vào git để chuẩn bị commit

    <img width="806" alt="image" src="https://github.com/FSEOrg/FSE09-BigTech/assets/6292433/734b88f7-bb9b-4ef7-b0f9-1f0d40c9d359">
    
    Để quản lý những file cần add vào git để chuẩn bị commit
    - Muốn add file nào vào git để commit thì cú pháp `git add "ten file"`
    - Muốn loại bỏ file nào khỏi việc commit thì cú pháp `git restore --unstage "ten file"`
    - Muốn add tất cả các file vào git để commit thì cú pháp `git add .` (cái này sẽ add tất cả các file bao gồm các file rác nên cẩn thận)

    Kiểm tra lại những file mình cần commit đều được chuyển sang màu xanh hết chưa
    ```
    git status
    ```

    Commit code và push lên remote
    ```
    git commit -m 'HW02 - Ten Cua Ban'
    git push origin hw02-maithanhhiep
    ```
 7. Mở trang web https://github.com/FSEOrg/FSE09-BigTech , bạn sẽ thấy có nút để tạo Pull Request, hãy tạo Pull Request để các giảng viên review nhé.
