class Solution:
    def isPalindrome(self, x: int) -> bool:
        # return str(x) == str(x)[::-1]

        # TC: O(logN)
        # SC: O(logN)
        if x < 0:
            return False 
        if x < 10:
            return True
        digits = []
        while x > 0:
            x, digit = divmod(x, 10)
            digits.append(digit) 

            x = x// 10   
            # digit = x % 10
            # x = x// 10

        for i in range(len(digits)//2 + 1):
            if digits[i] != digits[-1 - i]:
                return False
        return True

        # log_10(100) = 2

        # log_10(10^9) = 9

        # log_10(121) = 2.xy

        # So chu so cua so N se la O(log10(N)) = O(logN)


