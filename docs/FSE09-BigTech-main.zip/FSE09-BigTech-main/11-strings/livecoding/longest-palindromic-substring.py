class Solution:
    def longestPalindrome(self, s: str) -> str:
        # Brute-force: Generate all substrings (there are O(N^2) such substrings), then verify each of them is a palindrome (O(N)) 
--> O(N^3)

        # abbba --> bbb --> b 

        # babad
        #   -

        # s[i:j] is a palindrome --> s[i - 1:j + 1] --> s[i - 2: j + 2]

        # Idea: starts from a 1-length or 0-length substring. Expand the substrings both to the left and the right, each time 1 
character. If the expanded substring is still a palindrome, continue. Otherwise, halt. 
        # "babad"
        # "b" --> 1
        # "a" --> "bab" --> 3
        # "b" --> "aba" --> "babad" --> x 
        # "a" --> "bad" --> x
        # "d" --> 

        # "" -> "ba"
        # "" -> "ab"
        # "" -> "ba"
        # "" -> "ad"
        
        # TC: O(N^2)
        # SC: O(1)
        palindrome_ends = (-1, -1)
        def expand(i, j):
            """
                Expand the palindromic substring s[i:j + 1]
            """
            nonlocal palindrome_ends
            while i >= 0 and j < len(s):
                if s[i] == s[j]:
                    if j - i + 1 > palindrome_ends[1] - palindrome_ends[0]:
                        palindrome_ends = (i, j)
                    i -= 1
                    j += 1
                else:
                    return
        
        for i in range(len(s)):
            expand(i, i)
            if i > 0:
                expand(i, i - 1)
        return s[palindrome_ends[0]: palindrome_ends[1] + 1]
                    
                    
                    




