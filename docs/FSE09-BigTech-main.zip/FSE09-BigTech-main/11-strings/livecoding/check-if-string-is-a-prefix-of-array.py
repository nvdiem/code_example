class Solution:
    def isPrefixString(self, s: str, words: List[str]) -> bool:
        # Idea: Find k such that len(s) = sum(len(words[:k])). Then compare s to concat(words[:k]).

        # TC: O(min(M, N)) where N = total number of characters in words, M = len(s)
        # SC: O(N)

        current_length = 0
        for idx, word in enumerate(words):
            current_length += len(word)
            if current_length >= len(s):
                return s == "".join(words[:idx + 1])
        return False

