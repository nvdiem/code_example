class Solution:
    def longestCommonPrefix(self, strs: List[str]) -> str:
        # Idea: Starts an index i from 0. Terminate when there is a j such that strs[j][i] != strs[0][i]

        # TC: O(M * N), with M = number of strings, N = maximum number of characters in a string
        # SC: O(1)

        i = 0
        while True:
            for j in range(len(strs)):
                if i >= len(strs[j]) or strs[j][i] != strs[0][i]:
                    return strs[0][:i]
            i += 1
        return ""
        
                
