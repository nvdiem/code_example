"""
Problem link: https://leetcode.com/problems/longest-subsequence-with-limited-sum/

Idea: 
Time complexity:
Space complexity:
"""

class Solution:
    def answerQueries(self, nums: List[int], queries: List[int]) -> List[int]:
        