"""
Problem link: https://leetcode.com/problems/find-peak-element/
Time complexity:
Space complexity:
"""

class Solution:
    def findPeakElement(self, nums: List[int]) -> int:
        