"""
Problem Link: https://leetcode.com/problems/valid-perfect-square/
"""

class Solution:
    def isPerfectSquare(self, num: int) -> bool:
        pass