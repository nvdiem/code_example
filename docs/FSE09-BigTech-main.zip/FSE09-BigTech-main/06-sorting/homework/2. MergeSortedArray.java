/*
    Problem Link: https://leetcode.com/problems/merge-sorted-array/
    Idea:
    Time complexity:
    Space Complexity:
*/

class Solution {
    public void merge(int[] nums1, int m, int[] nums2, int n) {
        //your code here
    }
}