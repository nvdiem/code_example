/*
    Problem Link: https://leetcode.com/problems/merge-intervals/
    Idea:
    Time complexity:
    Space Complexity:
*/

class Solution {
    public int[][] merge(int[][] intervals) {
        //your code here       
    }
}