/*
    Problem Link: https://leetcode.com/problems/merge-two-sorted-lists/
    Idea:
    Time complexity:
    Space Complexity:
*/

class Solution {
    public ListNode mergeTwoLists(ListNode list1, ListNode list2) {
        //your code here
    }
}