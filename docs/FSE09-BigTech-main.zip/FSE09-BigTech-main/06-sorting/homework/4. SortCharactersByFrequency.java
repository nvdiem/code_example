/*
    Problem Link: https://leetcode.com/problems/sort-characters-by-frequency/
    Idea:
    Time complexity:
    Space Complexity:
*/

class Solution {
    public String frequencySort(String s) {
        //your code here
    }
}