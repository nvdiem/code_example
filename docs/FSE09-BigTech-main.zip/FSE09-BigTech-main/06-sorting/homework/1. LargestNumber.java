/*
    Problem Link: https://leetcode.com/problems/largest-number/
    Idea:
    Time complexity:
    Space Complexity:
*/

class Solution {
    public String largestNumber(int[] nums) {
        //your code here
    }
}