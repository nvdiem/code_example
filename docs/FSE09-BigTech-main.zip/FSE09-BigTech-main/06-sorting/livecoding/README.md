# Sorting - Live Coding Solutions

Lecturer: Truong Quy Quynh

## 1. Selection sort
Link problem: lecture slides
```java
class Solution {
    public static void selectionSort(int[] nums) {
        int n = nums.length;
        int currentIndex = 0;
        while(currentIndex < n) {
            // tim gia tri nho nhat tu doan [currentIndex - (n - 1)]
            int minIndex = currentIndex;
            for(int i = minIndex + 1; i < n; i++) {
                if (nums[i] < nums[minIndex]) {
                    minIndex = i;
                }
            }
            swap(nums, currentIndex, minIndex);
            currentIndex++;
        }
    }

    public static void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }
}

```
Complexity:

- Time: `O(N^2)` where `N` is length of the array
- Space: `O(1)`

## 2. Pankae sorting

Link problem: https://leetcode.com/problems/pancake-sorting/

```java
class Solution {
    public List<Integer> pancakeSort(int[] nums) {
        int n = nums.length;
        List<Integer> result = new ArrayList<>();
        int currentIndex = n - 1;
        while(currentIndex >= 0) {
            int maxIndex = currentIndex;
            for(int i = 0; i < currentIndex; i++) {
                if (nums[i] > nums[maxIndex]) {
                    maxIndex = i;
                }
            }
            // maxIndex chinh la vi tri cua phan tu lon nhat trong doan [currentIndex - (n-1)]
            flip(nums, maxIndex);
            result.add(maxIndex + 1);
            flip(nums, currentIndex);
            result.add(currentIndex + 1);
            currentIndex--;
        }
        return result;
    }

    public void flip(int[] nums, int index) {
        int l = 0, r = index;
        while(l < r) {
            swap(nums, l, r);
            l++;
            r--;
        }
    }

    public void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }
}
```

Complexity:

- Time: `O(N^2)` where `N` is length of the array
- Space: `O(1)`


## 3.   Merge Sorted Array

Link problem: https://leetcode.com/problems/merge-sorted-array/

```java
class Solution {
    public void merge(int[] nums1, int m, int[] nums2, int n) {
        int[] result = new int[m+n];
        int i = 0, j = 0;
        int index = 0;
        while(i < m && j < n) {
            if (nums1[i] < nums2[j]) {
                result[index++] = nums1[i++];
            } else {
                result[index++] = nums2[j++];
            }
        }
        // Neu day 1 con thua phan tu
        while(i < m) {
            result[index++] = nums1[i++];
        }
        // Neu day 2 con thua phan tu
        while(j < n) {
            result[index++] = nums2[j++];
        }
        System.arraycopy(result, 0, nums1, 0, result.length);
    }
}


```

Complexity:

- Time: `O(M + N)` where `M` is the  length of `nums1`,  `N` is the length of `nums2`
- Space: `O(N)`



## 4.    Sort an Array

Link problem: https://leetcode.com/problems/sort-an-array/

**Solution: using merge sort**

```java

class Solution {
    public int[] sortArray(int[] nums) {
        mergeSort(nums, nums.length);
        return nums;
    }

    //sort day nums co do dai n
    public void mergeSort(int[] nums, int n) {
        if (n == 1) {
            return;
        }
        // Chia day ra lam 2 day
        int mid = n / 2;
        // Clone day ben trai
        int[] left = new int[mid];
        for(int i = 0; i < mid; i++) {
            left[i] = nums[i];
        }
        // Clone day ben phai
        int[] right = new int[n - mid];
        for(int i = 0; i < n - mid; i++) {
            right[i] = nums[i + mid];
        }
        mergeSort(left, mid);
        mergeSort(right, n - mid);        
        merge(left, mid, right, n - mid, nums);
    }

    /*  
        Merge 2 day left va right (2 day da duoc sort) vao day nums
    */
    public void merge(int[] left, int m, int[] right, int n, int[] nums) {
        int i = 0, j = 0, count = 0;
        while(i < m && j < n) {
            if (left[i] < right[j]) {
                nums[count++] = left[i++];
            } else {
                nums[count++] = right[j++];
            }
        }
        while(i < m) {
            nums[count++] = left[i++];
        }
        while(j < n) {
            nums[count++] = right[j++];
        }
    }
}
```

Complexity:
- Time: `O(N*LogN)` where `N` is length of the array.
- Space: `O(N*LogN)`

**Solution: using quick sort**

```java
class Solution {
    Random rand = new Random();

    public int[] sortArray(int[] nums) {
        quickSort(nums, 0, nums.length - 1);
        return nums;
    }

    // Sap xep day nums tu vi tri start den vi tri end     
    public void quickSort(int[] nums, int start, int end) {
        if (start >= end) {
            return;
        }
        // Buoc 1: chon so x
        int randomPos = rand.nextInt(end - start + 1) + start;
        swap(nums, randomPos, end);
        int x = nums[end];
        // Buoc 2: nem tat ca cac phan tu nho hon x sang ben trai
        int count = start;
        for(int i = count; i < end; i++) {
            if (nums[i] < x) {
                swap(nums, count, i);
                count++;
            }
        }
        // Nem x ve dung vi tri
        swap(nums, count, end);
        quickSort(nums, start, count - 1);
        quickSort(nums, count+ 1, end);
    }

    public void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }
}
```
Complexity:
- Time: `O(N*LogN)` where `N` is length of the array (on average).
- Space: `O(1)`

## 5.    Sort Colors

Problem link: https://leetcode.com/problems/sort-colors/

**Solution: quick sort-like solution**

```java
class Solution {
    public void sortColors(int[] nums) {
        int n = nums.length;
        // Nem cac phan tu 0 sang ben trai
        int count = 0;
        for(int i = 0; i < n; i++) {
            if (nums[i] == 0) {
                swap(nums, count, i);
                count++;
            }
        }
        // Nem cac phan tu 2 sang ben phai
        count = n - 1;
        for(int i = n-1; i >= 0; i--) {
            if (nums[i] == 2) {
                swap(nums, count, i);
                count--;
            }
        }        
    }

    public void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }
}
```

Complexity:

- Time: `O(N)` where `N` is length of the array.
- Space: `O(1)`
