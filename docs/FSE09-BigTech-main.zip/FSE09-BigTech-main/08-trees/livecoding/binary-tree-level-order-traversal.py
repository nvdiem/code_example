# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        # Idea: su dung BFS
        # TC: - BFS - O(N)
        # SC: - BFS - O(N)
        if root is None:
            return []
        dq = deque()
        dq.append((root, 0))

        current_depth = -1
        ans = []
        while dq:
            node, depth = dq.popleft()
            if depth > current_depth:
                ans.append([node.val])
                current_depth += 1
            else:
                ans[-1].append(node.val)
            
            if node.left:
                dq.append((node.left, depth + 1))
            if node.right:
                dq.append((node.right, depth + 1))
        
        return ans


