# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def isSymmetric(self, root: Optional[TreeNode]) -> bool:
        # Idea: Sử dụng tính chất truy hồi
        # is_mirror(u, v) = True nếu như subtree ở node u là mirror của subtree ở node v.
        # is_mirror(u, v) = True nêu u.val == v.val, is_mirror(u.left, v.right), is_mirror(u.right, v.left)

        # TC: O(N)
        # SC: O(H)
        
        def is_mirror(u, v):
            if u is None:
                return v is None
            if v is None:
                return False
            return u.val == v.val and is_mirror(u.left, v.right) and is_mirror(u.right, v.left)
        
        if root is None:
            return True
        return is_mirror(root.left, root.right)
            
