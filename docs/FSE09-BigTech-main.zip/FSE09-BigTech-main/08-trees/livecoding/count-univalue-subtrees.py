# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def countUnivalSubtrees(self, root: Optional[TreeNode]) -> int:
        # Idea:
        # is_unival(u) = True if: is_unival(u.left) and is_unival(u.right) and u.val == u.left.val == u.right.val

        # TC: O(N) 
        # SC: O(H)
        
        ans = 0
        def is_unival(u):
            nonlocal ans
            if u is None:
                return True 
            is_left_unival = is_unival(u.left)
            is_right_unival = is_unival(u.right)

            left_condition = u.left is None or (u.val == u.left.val and is_left_unival)
            right_condition = u.right is None or (u.val == u.right.val and is_right_unival)

            if left_condition and right_condition:
                ans += 1
                return True
            return False
        
        _ = is_unival(root)
        return ans
                

# Lintcode: https://www.lintcode.com/problem/921/
