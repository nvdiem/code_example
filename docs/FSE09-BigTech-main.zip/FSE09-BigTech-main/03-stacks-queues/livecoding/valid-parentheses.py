class Solution(object):
    def isValid(self, s):
        """
        :type s: str
        :rtype: bool
        """

        # TC: O(N), N = len(s)
        # SC: O(N)

        # Idea: Maintain a stack S that contains open parentheses ( [ {.
        # Each time we encounter an oopen parenthesis, push it into S.
        # When we encounter a close parenthesis, verify that it matches the top of the stack. If it does, pop from the stack. 
Otherwise, return False.

        # [], (), {} ok, [} not ok
        # [{}], ([]) ok, [(]) not ok
        # [], [{}()], [} not ok

        stack = []
        pairs = {'(': ')', '[': ']', '{':'}'}
        for char in s:
            if char in "([{":
                stack.append(char)
            elif char in ")}]":
                if len(stack) > 0 and char == pairs[stack.pop()]:
                    continue
                return False
        return len(stack) == 0
