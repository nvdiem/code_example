from collections import deque
class RecentCounter(object):

    # Idea:
    # Let Q = a queue of request times t. Each time ping(t) is called, add t to Q. Expire all the timestamps u such that u + 3000 < t.

    # Time Complexity: O(N) for all ping() requests
    # Space Complexity: O(N)
    def __init__(self):
        self.queue = deque()

    def ping(self, t):
        """
        :type t: int
        :rtype: int
        """
        self.queue.append(t)
        while self.queue[0] + 3000 < t:
            self.queue.popleft()
        return len(self.queue)


# Your RecentCounter object will be instantiated and called as such:
# obj = RecentCounter()
# param_1 = obj.ping(t)
