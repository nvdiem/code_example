class Solution(object):
    def deckRevealedIncreasing(self, deck):
        """
        :type deck: List[int]
        :rtype: List[int]
        """

        # Forward
        # [2, 13, 3, 11, 5, 17, 7] -> [13, 3, 11, 5, 17, 7] | 2 
        # --> [3, 11, 5, 17, 7, 13] | 2 --> [11, 5, 17, 7, 13] | 2, 3
        # --> [5, 17, 7, 13, 11] | 2, 3 --> [17, 7, 13, 11] | 2, 3, 5
        # --> [7, 13, 11, 17] | 2, 3, 5 --> [13, 11, 17] | 2, 3, 5, 7
        # --> [11, 17, 13] | 2, 3, 5, 7 --> [17, 13] | 2, 3, 5, 7, 11
        # --> [13, 17] | 2, 3, 5, 7, 11--> [17] | 2, 3, 5, 7, 11, 13 
        # --> [] | 2, 3, 5, 7, 11, 13, 17

        # Backward
        # 17 --> [17]
        # 13 --> [13, 17]
        # 11 --> [11, 17, 13]
        # 7 --> [7, 13, 11, 17]
        # 5 --> [5, 17, 7, 13, 11]
        # 3 --> [3, 11, 5, 17, 7, 13]
        # 2 --> [2, 13, 3, 11, 5, 17, 7]

        # Idea: Sort the decks in decreasing order (17 -> 2)

        # D = [deck[0]]
        # D = deck[1] + D[1:] + D[0]
        # D = deck[2] + D[1:] + D[0]
        # ...
        # return D

        # TC: O(NlogN)
        # SC: O(N)

        deck.sort(reverse = True)
        D = deque()
        D.append(deck[0])
        for i in range(1, len(deck)):
            D.appendleft(D.pop())
            D.appendleft(deck[i])
            # print(D)
        return D
        



