class MinStack(object):
    # monostack
    # Idea: use 2 stacks: stack, min_stack
    # min_stack is a monostack that stores element indices in decreasing order

    # t = 0 [], []
    # t = 1 [-2] [-2] --> [0]
    # t = 2 [-2, 0], [-2] --> [0]
    # t = 3 [-2, 0, -3], [-2, -3] --> [0, 2]
    # t = 4 [-2, 0], [-2] --> [0]

    # TC: O(1) for each method
    # SC: O(N), N = number of push() calls
    def __init__(self):
        self.stack = []
        self.min_stack = []

    def push(self, val):
        """
        :type val: int
        :rtype: None
        """
        self.stack.append(val)
        if len(self.min_stack) == 0 or val < self.stack[self.min_stack[-1]]:
            self.min_stack.append(len(self.stack) - 1)
        

    def pop(self):
        """
        :rtype: None
        """
        self.stack.pop()
        if len(self.min_stack) > 0 and self.min_stack[-1] == len(self.stack):
            self.min_stack.pop()

    def top(self):
        """
        :rtype: int
        """
        return self.stack[-1]
        

    def getMin(self):
        """
        :rtype: int
        """
        return self.stack[self.min_stack[-1]]


# Your MinStack object will be instantiated and called as such:
# obj = MinStack()
# obj.push(val)
# obj.pop()
# param_3 = obj.top()
# param_4 = obj.getMin()
