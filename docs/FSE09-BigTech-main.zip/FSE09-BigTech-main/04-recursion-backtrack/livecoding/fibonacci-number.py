class Solution:
    # Time Complexity: O(N)
    # Space: O(N) (for recursion) + O(N) (memo) = O(N)

    @lru_cache(None)
    def fib(self, n: int) -> int:
        # B1: Done
        # B2: Done
        # B3: Done
        # B4: Code
        if n == 0 or n == 1:
            return n
        result = self.fib(n - 1) + self.fib(n - 2)
        return result

    # F(100) --> F(99), F(98) --> F(98) + F(97) + F(98)

    # Stack de quy: S(100) | S(98) | S(97) | ... | S(2)

    # 
