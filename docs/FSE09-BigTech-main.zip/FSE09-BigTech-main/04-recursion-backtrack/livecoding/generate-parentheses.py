class Solution:
    def generateParenthesis(self, n: int) -> List[str]:
        # 1. At the end, number of ( = number of )
        # 2. At any point, number of ) <= number (

        current_solution = []
        ans = []
        used_open, used_close = 0, 0 # number of used (, number of used )

        def choose(i):
            '''
                Choose the i-th position for current_solution
            '''
            nonlocal used_open, used_close
            # Base case
            if i == 2*n:
                if used_open == n and used_close == n:
                    ans.append("".join(current_solution))
                return
            
            # Recursion

            # P1: Use (
            if used_open + 1 <= n:
                current_solution.append("(")
                used_open += 1
                choose(i + 1)
                used_open -= 1
                current_solution.pop()
            
            # P2: Use )
            if used_close + 1 <= used_open:
                current_solution.append(")")
                used_close += 1
                choose(i + 1)
                used_close -= 1
                current_solution.pop()
        
        choose(0)
        return ans

        # TC: O(N * 2^(2N)) = O(N* 4^N)
        # SC: O(N) (current_solution) + O(N) (choose) + O(1) (used_close, used_open)= O(N)
