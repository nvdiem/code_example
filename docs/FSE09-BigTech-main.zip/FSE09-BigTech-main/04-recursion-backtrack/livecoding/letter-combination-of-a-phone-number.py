class Solution:
    def letterCombinations(self, digits: str) -> List[str]:
        if len(digits) == 0:
            return []
        current_solution = []
        ans = []

        mapping = {
            "2": "abc",
            "3": "def",
            "4": "ghi",
            "5": "jkl",
            "6": "mno",
            "7": "pqrs",
            "8": "tuv",
            "9": "wxyz"
        }

        def choose(i):
            '''
                Choose the i-th character for the result string
            '''
            # Base case
            if i == len(digits):
                ans.append("".join(current_solution))
                return
            
            # Recursion
            for char in mapping[digits[i]]:
                current_solution.append(char)
                choose(i + 1)
                current_solution.pop()
        
        choose(0)

        return ans
        
        # There are at most 4^N strings 

        # TC: O(N * 4^N)

        # SC: O(N) (current_solution) + O(1) (mapping) + O(N) (backtrack) = O(N)
       
       
        # a = ["1", "20", "3"]
        # "".join(a) = "1203"
        # ",".join(a) = "1,20,3"


        # current_solution = ["ad"] --> ghi ket qua ["a"] -> ["ae"] --> ghi ket qua --> ["a"] --> ["af"] 
