class Solution:
    def generate(self, numRows: int) -> List[List[int]]:
        # B1: Determine F
        # Let F(i, j) be the number on i-th row and j-th column (0-indexed) of the 
        # Pascal triangle

        # B2: Base case: F(i, 0) = F(i, i) = 1 for each i

        # B3: Recursive relation: F(i, j) = F(i - 1, j - 1) + F(i - 1, j)
        @lru_cache(None)
        def F(i: int, j: int) -> int:
            '''
                Returns the number at i-th row, j-th column
            '''
            # print(i, j)
            if j == 0 or j == i:
                return 1
            return F(i - 1, j - 1) + F(i - 1, j)

        ans = [[] for i in range(numRows)]
        for i in range(numRows):
            for j in range(i + 1):
                ans[i].append(F(i, j))
        return ans

        # F(i, j) --> F(i - 1, j - 1), F(i - 1, j) --> F(i - 2, j - 1) 
