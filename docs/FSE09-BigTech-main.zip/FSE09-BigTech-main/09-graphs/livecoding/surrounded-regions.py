class Solution:
    def solve(self, board: List[List[str]]) -> None:
        """
        Do not return anything, modify board in-place instead.
        """
        # Idea: Try to go from the borders to the 'O' inside the board
        # If there's no way to access the 'O' cell from the border, then the 'O' cell is captured.

        # TC: O(m * n)
        # SC: O(m * n)
        m, n = len(board), len(board[0])
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        visited = set()
        is_accessible_from_borders = set()

        def dfs(i, j):
            visited.add((i, j))
            is_accessible_from_borders.add((i, j))
            for dx, dy in directions:
                x, y = i + dx, j + dy
                if 0 <= x < m and 0 <= y < n and (x, y) not in visited and board[x][y] == 'O':
                    dfs(x, y)
        
        for i in range(m):
            dfs(i, -1)
            dfs(i, n)
        for j in range(n):
            dfs(-1, j)
            dfs(m, j)
        
        # print(is_accessible_from_borders)
        for i in range(m):
            for j in range(n):
                if board[i][j] == 'O' and (i, j) not in is_accessible_from_borders:
                    board[i][j] = 'X'
        
        return board

                
