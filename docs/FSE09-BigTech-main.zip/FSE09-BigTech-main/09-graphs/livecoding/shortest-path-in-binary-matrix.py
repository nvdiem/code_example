class Solution:
    def shortestPathBinaryMatrix(self, grid: List[List[int]]) -> int:

        # TC: O(M + N) voi M la so dinh, N la so canh = O(n^2)
        # SC: O(N) = O(n^2)
        # Idea: View the binary matrix as a graph, use BFS to find the length of the shortest "clear" path on the graph.

        directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
        n = len(grid)
        if grid[0][0] == 1:
            return -1
        dq = deque()
        visited = set()
        dq.append((0, 0, 0)) # (length from (0, 0) to (i, j), i, j)
        visited.add((0, 0))

        while dq:
            d, u, v = dq.popleft()
            if (u, v) == (n - 1, n - 1):
                return d + 1
            for dx, dy in directions:
                x, y = u + dx, v + dy
                if 0 <= x < n and 0 <= y < n and (x, y) not in visited and grid[x][y] == 0:
                    visited.add((x, y))
                    dq.append((d + 1, x, y))
                
        return -1

