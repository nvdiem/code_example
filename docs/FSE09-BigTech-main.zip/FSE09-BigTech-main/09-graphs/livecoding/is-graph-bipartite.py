class Solution:
    def isBipartite(self, graph: List[List[int]]) -> bool:
        # Idea: Let color[u] be the color of node u. Initially, every vertice is unvisited (white, -1). Try to color u so that if 
u is red (0), then all its adjancent vertices v is black and vice versa. 
        # At the end of the DFS, if there is no violation found, then the graph is bipartite. 

        # TC: O(sum(deg(u)) + n) for all u --> O(2*M + N) = O(M + N) 
        # SC: O(M + N)
        n = len(graph)
        color_of = [-1] * n
        ans = True

        def dfs(u):
            nonlocal ans
            for v in graph[u]:
                # if v is unvisited, then visit v
                if color_of[v] == -1:
                    color_of[v] = 1 - color_of[u]
                    dfs(v)
                # if v and u have the same color, then this is not a bipartite graph
                elif color_of[v] == color_of[u]: 
                    ans = False
            
        for u in range(n):
            if color_of[u] == -1:
                color_of[u] = 0
                dfs(u)
        
        return ans
        



