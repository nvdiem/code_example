class Solution:
    def allPathsSourceTarget(self, graph: List[List[int]]) -> List[List[int]]:
        # B1: Graph representation
        # Done
        # B2: Use DFS to traverse the graph

        # TC: O(N * 2^(N - 2))
        # SC: O(N)

        n = len(graph)
        path = []
        ans = []
        def dfs(u):
            '''
                Visit u
            '''
            if u == n - 1:
                ans.append(path.copy() + [n - 1])
                return
            path.append(u)
            for v in graph[u]:
                dfs(v)
            path.pop()
        dfs(0)
        return ans
                
        # Tìm xem với độ thị DAG có N đỉnh, thì số đường đi từ 0->N - 1 nhiều nhất có thể  là bao nhiêu?
        # N = 2, 0->1
        # N = 3, 0->2, 0->1->2
        # N = 4, 0->1->2->3, 0->1->3, 0->2->3, 0->3
        # Đoán: số lượng đường đi là 2^(N - 2)

        # Chứng minh bằng quy nạp:
        # Giả sử: với đồ thị K - 1 đỉnh, số lượng đường đi là 2^(K - 3)
        # Cần chứng minh: với đồ thị K đỉnh, số đường đi là 2^(K - 2)
        # 1. Với 2^(K - 3) đường đi cũ từ 0-> K - 2, thêm K - 1 vào cuối ta sẽ thu được đường đi mới.
        # 2. Với 2^(K - 3) đường đi cũ từ 0-> K - 2, thay K - 2 bằng K - 1, ta cũng thu được đường đi mới









