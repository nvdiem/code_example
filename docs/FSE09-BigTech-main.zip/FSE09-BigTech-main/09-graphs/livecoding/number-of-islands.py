class Solution:
    def numIslands(self, grid: List[List[str]]) -> int:
        # Idea: Use BFS to traverse through all connected components. Each time we do BFS, increase the number of connected 
components by 1.

        # TC: O(1) * N + O(N) = O(N) = O(m*n)
        # SC: O(m*n)
        m, n = len(grid), len(grid[0])
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        visited = set()
        ans = 0

        def bfs(i, j):
            '''
                BFS starting from (i, j) to all the '1' cells connected to it
            '''
            dq = deque()
            dq.append((i, j))
            visited.add((i, j))
            while dq:
                u, v = dq.popleft()
                for dx, dy in directions:
                    x, y = u + dx, v + dy
                    if 0 <= x < m and 0 <= y < n and (x, y) not in visited and grid[x][y] == "1":
                        visited.add((x, y))
                        dq.append((x, y))
        
        for i in range(m):
            for j in range(n):
                if grid[i][j] == "1" and (i, j) not in visited:
                    ans += 1
                    bfs(i, j)
        
        return ans



