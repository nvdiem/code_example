# Hash Table

Speaker: Mai Thanh Hiep

## 1. Design HashMap

Link problem: https://leetcode.com/problems/design-hashmap/description/

```python
class MyHashMap:

    def __init__(self, init_capacity = 100):
        self.buckets = [[] for _ in range(init_capacity)]

    def get_bucket_index(self, key: int) -> int:
        return key % len(self.buckets)

    def put(self, key: int, value: int) -> None:
        bucket_index = self.get_bucket_index(key)
        for i, (k, v) in enumerate(self.buckets[bucket_index]):
            if k == key:
                self.buckets[bucket_index][i] = (key, value)
                return
        self.buckets[bucket_index].append((key, value))
        
    def get(self, key: int) -> int:
        bucket_index = self.get_bucket_index(key)
        for k, v in self.buckets[bucket_index]:
            if k == key:
                return v
        return -1
        
    def remove(self, key: int) -> None:
        bucket_index = self.get_bucket_index(key)
        for i, (k, v) in enumerate(self.buckets[bucket_index]):
            if k == key:
                del self.buckets[bucket_index][i]
                return
```

Complexity:

- Time: `O(N/K)`, where `N` is length of `nums` array, `K` is the `init_capacity`



## 2. Design HashMap - Support `loadFactor`

Link problem: https://leetcode.com/problems/design-hashmap/description/


```python
class MyHashMap:

    def __init__(self, init_capacity = 10, load_factor = 0.75):
        self.buckets = [[] for _ in range(init_capacity)]
        self.load_factor = load_factor
        self.size = 0

    def get_bucket_index(self, key: int) -> int:
        return key % len(self.buckets)

    def put(self, key: int, value: int) -> None:
        bucket_index = self.get_bucket_index(key)
        for i, (k, v) in enumerate(self.buckets[bucket_index]):
            if k == key:
                self.buckets[bucket_index][i] = (key, value)
                return
        self.buckets[bucket_index].append((key, value))
        self.size += 1
        if self.size / len(self.buckets) > self.load_factor:
            self.rehashing()

    def rehashing(self):
        old_buckets = self.buckets
        new_capacity = len(old_buckets) << 1
        self.buckets = [[] for _ in range(new_capacity)]
        self.size = 0
        for bucket in old_buckets:
            for k, v in bucket:
                self.put(k, v)
        
    def get(self, key: int) -> int:
        bucket_index = self.get_bucket_index(key)
        for k, v in self.buckets[bucket_index]:
            if k == key:
                return v
        return -1
        
    def remove(self, key: int) -> None:
        bucket_index = self.get_bucket_index(key)
        for i, (k, v) in enumerate(self.buckets[bucket_index]):
            if k == key:
                del self.buckets[bucket_index][i]
                self.size -= 1
                return
```

Complexity:

- Time: xấp xỉ `O(1)`



## 3. Max Number of K-Sum Pairs

Link problem: https://leetcode.com/problems/max-number-of-k-sum-pairs/

```python
class Solution:
    def maxOperations(self, nums: List[int], k: int) -> int:
        cnt = defaultdict(int)
        ans = 0

        for num in nums:
            complement = k - num
            if complement in cnt and cnt[complement] > 0:
                ans += 1
                cnt[complement] -= 1
            else:
                cnt[num] += 1
        return ans
```

Complexity:

- Time: `O(N)`, where `N` is number of elements in nums array
- Space: `O(N)`



## 4. Group Anagrams - 3 approaches to get keys

Problem link: https://leetcode.com/problems/group-anagrams/

```python
class Solution:
    def groupAnagrams(self, strs: List[str]) -> List[List[str]]:
        groups = defaultdict(list)
        for s in strs:
            key = self.getKeyV3(s)
            groups[key].append(s)
        return groups.values()


    def getKeyV1(self, key): # O(LlogL)
        return "".join(sorted(key))

    def getKeyV2(self, key): # ~O(L)
        cnt = Counter(key)
        ans = []
        for c in ascii_lowercase:
            if cnt[c] > 0:
                ans.append(c)
                ans.append(str(cnt[c]))
                ans.append(",")
        return "".join(ans)

    def getKeyV3(self, key): # O(L)
        cnt = Counter(key)
        ans = []
        for c in ascii_lowercase:
            while cnt[c] > 0:
                ans.append(c)
                cnt[c] -= 1
                
        return "".join(ans)
```


## 5. Maximum Size Subarray Sum Equals k

Problem link: https://leetcode.com/problems/maximum-size-subarray-sum-equals-k/ or https://www.geeksforgeeks.org/longest-sub-array-sum-k/

```python
class Solution:
    def maxSubArrayLen(self, nums: List[int], k: int) -> int:
        seen = {}
        seen[0] = -1
        preSumR = 0
        ans = 0
        for i, num in enumerate(nums):
            preSumR += num
            preSumL = preSumR - k
            if preSumL in seen:
                # preSum[R] - preSum[L] = k
                ans = max(ans, i - seen[preSumL])
            if preSumR not in seen:
                seen[preSumR] = i

        return ans
```

Complexity:

- Time: `O(N)`, where `N` is number of elements in nums array
- Space: `O(N)`
