"""
Problem Link: https://leetcode.com/problems/design-hashset/

Idea:

Time complexity:

Space complexity:

"""

class MyHashSet:

    def __init__(self):
        

    def add(self, key: int) -> None:
        

    def remove(self, key: int) -> None:
        

    def contains(self, key: int) -> bool:
        


# Your MyHashSet object will be instantiated and called as such:
# obj = MyHashSet()
# obj.add(key)
# obj.remove(key)
# param_3 = obj.contains(key)