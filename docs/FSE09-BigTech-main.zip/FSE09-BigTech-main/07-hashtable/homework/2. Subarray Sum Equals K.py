"""
Problem Link: https://leetcode.com/problems/subarray-sum-equals-k/

Idea:

Time complexity:

Space complexity:

"""

class Solution:
    def subarraySum(self, nums: List[int], k: int) -> int:
        pass