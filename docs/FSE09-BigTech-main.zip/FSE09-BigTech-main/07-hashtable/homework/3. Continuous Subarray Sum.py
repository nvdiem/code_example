"""
Problem Link: https://leetcode.com/problems/continuous-subarray-sum/

Idea:

Time complexity:

Space complexity:

"""

class Solution:
    def checkSubarraySum(self, nums: List[int], k: int) -> bool:
        pass