"""
Problem Link: https://leetcode.com/problems/find-median-from-data-stream/

Idea:

Time complexity:

Space complexity:

"""

class MedianFinder:

    def __init__(self):
        

    def addNum(self, num: int) -> None:
        

    def findMedian(self) -> float:
        


# Your MedianFinder object will be instantiated and called as such:
# obj = MedianFinder()
# obj.addNum(num)
# param_2 = obj.findMedian()