"""
Problem Link: https://leetcode.com/problems/k-closest-points-to-origin/

Idea:

Time complexity:

Space complexity:

"""

class Solution:
    def kClosest(self, points: List[List[int]], k: int) -> List[List[int]]:
        