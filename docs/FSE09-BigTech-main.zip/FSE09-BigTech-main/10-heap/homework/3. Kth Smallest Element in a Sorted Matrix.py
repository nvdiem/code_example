"""
Problem Link: https://leetcode.com/problems/kth-smallest-element-in-a-sorted-matrix/

Idea:

Time complexity:

Space complexity:

"""

class Solution:
    def kthSmallest(self, matrix: List[List[int]], k: int) -> int:
        