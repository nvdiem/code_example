# Heap

Speaker: Mai Thanh Hiep

## 1. Common Heap Operations for MinHeap

```python
class MinHeap:
    @staticmethod
    def heapify_up(arr: List[int], index: int):
        """
        Bubble up the element at index 'index' until the heap property is satisfied.
        The heap property requires that the parent is smaller than its children.
        
        :param arr: The heap represented as a list.
        :param index: Index of the element to be heapified upwards.
        """
        while index > 0:
            parent = (index - 1) // 2  # Find the parent index
            # Swap with the parent if the element at index is smaller
            if arr[parent] > arr[index]:
                arr[parent], arr[index] = arr[index], arr[parent]
                index = parent  # Update index to continue checking upwards
            else:
                break

    @staticmethod
    def heapify_down(arr: List[int], n: int, index: int):
        """
        Bubble down the element at index 'index' until the heap property is satisfied.
        The heap property requires that the parent is smaller than its children.
        
        :param arr: The heap represented as a list.
        :param n: Total number of elements in the heap.
        :param index: Index of the element to be heapified downwards.
        """
        while True:
            smallest = index
            left = 2 * index + 1  # Find left child index
            right = 2 * index + 2  # Find right child index

            # Check if left child is smaller than the element at 'smallest'
            if left < n and arr[left] < arr[smallest]:
                smallest = left
            
            # Check if right child is smaller than the element at 'smallest'
            if right < n and arr[right] < arr[smallest]:
                smallest = right

            # Swap if the element at 'index' is not the smallest
            if smallest != index:
                arr[index], arr[smallest] = arr[smallest], arr[index]
                index = smallest  # Update index to continue checking downwards
            else:
                break

    @staticmethod
    def heapify(arr: List[int]):
        """
        Transform the list 'arr' into a valid heap in-place.
        
        :param arr: List of integers to be turned into a heap.
        """
        n = len(arr)
        # Start from the last non-leaf node and heapify_down each node
        for i in range(n//2-1, -1, -1):
            MinHeap.heapify_down(arr, n, i)

    @staticmethod
    def heap_push(arr: List[int], x: int):
        """
        Add a new element x into the heap 'arr', maintaining the heap property.
        
        :param arr: The heap represented as a list.
        :param x: The element to be inserted into the heap.
        """
        arr.append(x)  # Add the new element at the end of the heap
        # Heapify_up to ensure the heap property is maintained
        MinHeap.heapify_up(arr, len(arr) - 1)

    @staticmethod
    def heap_pop(arr: List[int]) -> int:
        """
        Remove and return the smallest element from the heap, maintaining the heap property.
        
        :param arr: The heap represented as a list.
        :return: The smallest element from the heap.
        :raises IndexError: When trying to pop from an empty heap.
        """
        if len(arr) == 0:
            raise IndexError("pop from an empty heap")

        # Swap the root (smallest element) with the last element
        arr[0], arr[-1] = arr[-1], arr[0]
        
        # Remove and save the last element (the original root, which is the minimum)
        popped_value = arr.pop()

        # Heapify_down to ensure the heap property is maintained
        MinHeap.heapify_down(arr, len(arr), 0)

        return popped_value
    

heap = []
MinHeap.heap_push(heap, 2)
MinHeap.heap_push(heap, 1)
MinHeap.heap_push(heap, 4)
print(MinHeap.heap_pop(heap)) # 1
print(MinHeap.heap_pop(heap)) # 2
MinHeap.heap_push(heap, 5)
print(MinHeap.heap_pop(heap)) # 4
print(MinHeap.heap_pop(heap)) # 5
```

Complexity:

- Time: 
   - `heapify_up`: O(logN)
   - `heapify_down`: O(logN)
   - `heapify`: O(N)
   - `heap_push`: O(logN)
   - `heap_pop`: O(logN)



## 2. Heap Sort


```python
class HeapSort:
    @staticmethod
    def heapify_down(arr: List[int], n: int, index: int):
        """
        Bubble down the element at index 'index' until the heap property is satisfied.
        The heap property requires that the parent is greater than or equal to its children.
        
        :param arr: The heap represented as a list.
        :param n: Total number of elements in the heap.
        :param index: Index of the element to be heapified downwards.
        """
        while True:
            largest = index
            left = 2 * index + 1  # Find left child index
            right = 2 * index + 2  # Find right child index

            # Check if left child is greater than the element at 'largest'
            if left < n and arr[left] > arr[largest]:
                largest = left
            
            # Check if right child is greater than the element at 'largest'
            if right < n and arr[right] > arr[largest]:
                largest = right

            # Swap if the element at 'index' is not the largest
            if largest != index:
                arr[index], arr[largest] = arr[largest], arr[index]
                index = largest  # Update index to continue checking downwards
            else:
                break
                
                
    @staticmethod
    def sort(arr: List[int]):
        """
        Sort an array in-place using the heap sort algorithm.

        :param arr: List of integers to be sorted.
        """
        n = len(arr)

        # Build a max-heap
        for i in range(n // 2 - 1, -1, -1):
            HeapSort.heapify_down(arr, n, i)

        # Extract elements from the heap one by one
        for i in range(n-1, 0, -1):
            # Swap the root of the heap with the last element
            arr[i], arr[0] = arr[0], arr[i]  

            # Heap size is reduced by one
            # Heapify the root element to get the largest element at the root again
            HeapSort.heapify_down(arr, i, 0)
```

Complexity:

- Time: O(NlogN)
- Space: O(1)



## 3. Kth Largest Element in an Array

Link problem: https://leetcode.com/problems/kth-largest-element-in-an-array/

Solution: https://leetcode.com/problems/kth-largest-element-in-an-array/solutions/1349609/python-4-solutions-minheap-maxheap-quickselect-clean-concise/



## 4. Furthest Building You Can Reach

Problem link: https://leetcode.com/problems/furthest-building-you-can-reach/

```python
class Solution:
    def furthestBuilding(self, heights: List[int], bricks: int, ladders: int) -> int:
        minHeap = []
        n = len(heights)
        for i in range(n-1):
            d = heights[i+1] - heights[i]
            if d > 0:
                heappush(minHeap, d)
            if len(minHeap) > ladders:
                bricks -= heappop(minHeap)
            if bricks < 0:
                return i

        return n - 1
```
Complexity:
- Time: `O(NlogM)`, where `N <= 10^5` is length of buildings, `M <= N` is the number of ladders
- Space: `O(M)`


## 5. Merge k Sorted Lists

Problem link: https://leetcode.com/problems/merge-k-sorted-lists/

Solution: https://leetcode.com/problems/merge-k-sorted-lists/solutions/1447503/python-3-solutions-merge-2-linked-list-divide-and-conquer-priority-queue-clean-concise/ 

