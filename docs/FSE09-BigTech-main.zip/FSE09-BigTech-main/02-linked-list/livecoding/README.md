# Linked List - Live Coding Solutions

Lecturer: Mai Thanh Hiep


## 1. Singly Linked List & Doubly Linked List

Problem: https://leetcode.com/problems/design-linked-list/

Solution: https://leetcode.com/problems/design-linked-list/solutions/1487653/python-singly-linked-list-double-linked-list-clean-concise/


## 2. Add Two Numbers

Problem: https://leetcode.com/problems/add-two-numbers/

Solution: https://leetcode.com/problems/add-two-numbers/solutions/1013409/java-python-supper-clean-concise/


## 3. Merge Two Sorted Lists

Problem: https://leetcode.com/problems/merge-two-sorted-lists/

Solution: https://leetcode.com/problems/merge-two-sorted-lists/solutions/1447438/python-merge-2-sorted-lists-clean-concise/


## 4. Reverse Linked List

Problem: https://leetcode.com/problems/reverse-linked-list/

Solution: https://leetcode.com/problems/reverse-linked-list/solutions/3886707/python-reverse-linked-list-clean-concise/


## 5. Middle of the Linked List

Problem: https://leetcode.com/problems/middle-of-the-linked-list/

Solution: https://leetcode.com/problems/middle-of-the-linked-list/solutions/3886713/python-middle-of-the-linked-list/

## 6. Linked List Cycle

Problem: https://leetcode.com/problems/linked-list-cycle/

Solution: https://leetcode.com/problems/linked-list-cycle/solutions/1450084/python-3-solutions-clean-concise/